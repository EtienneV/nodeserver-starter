const express = require('express')
const app = express()
var path = require('path');
var session = require('express-session')

var bodyParser = require('body-parser')
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 

var multer = require('multer'); // v1.0.5
var upload = multer(); // for parsing multipart/form-data

// On sert les fichiers dans "views" via /static
app.use('/static', express.static('views'));

// Use the session middleware
app.use(session({ secret: 'keyboard cat', cookie: { maxAge: 60000 }}))

function isLogged(session){
	return verifyLogin(session.login, session.pwd)
}

app.get('/', function (req, res) {

	if (isLogged(req.session)) { // Si on est loggé, on va sur le contenu
	    res.sendFile(path.join(__dirname + '/views/dashboard/index.html'));
	} else { // Sinon, on va sur l'écran de login
	    res.sendFile(path.join(__dirname + '/views/dashboard/auth.html'));
	}
})

function verifyLogin(login, pwd){
	if((login == "login") && (pwd == "mdp")) return true
	else return false
}

app.post('/login', upload.array(), function (req, res) {
	var login = req.body.login
	var pwd = req.body.password

	if(verifyLogin(login, pwd)) // Si l'utilisateur est enregistré
	{
		//Enregistrement des identifiants dans la session
		req.session.login = login;
		req.session.pwd = pwd;

		res.redirect("/")
	}
	else {
		res.sendFile(path.join(__dirname + '/views/dashboard/auth.html'));
	}
})

app.get('/logout', function (req, res) {
   req.session.destroy(function(err){
   	res.redirect("/")
   })
})

app.listen(3000, function () {
  console.log('Example app listening on port 3000!')
})
